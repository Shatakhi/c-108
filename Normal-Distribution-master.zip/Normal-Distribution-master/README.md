# Normal-Distribution
solution for c108
